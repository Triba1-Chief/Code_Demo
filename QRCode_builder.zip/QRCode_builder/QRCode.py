from logging import raiseExceptions
from Python.QRCode_builder.helper import *
from TxtData import *


class QRCode:
    """
    A class representing a QR code with metadata and methods for equality and corruption checks.

    Attributes:
        file_path (str): The file path of the QR code.
        last_update_date (dict): A dictionary with date components of the last update date.
        owner (str): The owner of the QR code.
        error_correction (float): Error correction tolerance for QR code comparison.
        data (TxtData): The data extracted from the QR code file.
    """



    def __init__(self, file_path, last_update_date = "00/00/0000", owner = "Default Owner", error_correction = 0.0):
        """
        Initializes a QRCode instance.

        Args:
            file_path (str): The path to the QR code data file.
            last_update_date (str): The last update date in DD/MM/YYYY format.
            owner (str): The owner of the QR code.
            error_correction (float): The error correction tolerance level.
        """

        self.file_path = file_path
        self.last_update_date = convert_date(last_update_date)
        self.owner = owner
        self.error_correction = error_correction
        self.data = TxtData(get_data(file_path))



    def __str__(self):
        """
        Returns a formatted string representation of the QRCode instance.

        Returns:
            str: Information about the QR code's owner, last update year, and data details.

        Example:
            >>> qr = QRCode("qr_data.txt", "15/04/2021", "Alice")
            >>> print(qr)
            The QR code was created by Alice and last updated in 2021.
            The details regarding the QR code file are as follows:
            This TxtData object has 10 rows and 10 columns.
        """

        return ("The QR code was created by " + self.owner + " and last updated in "
                + self.last_update_date.get("Year") + ".\n"
                + "The details regarding the QR code file are as follows:\n"
                + self.data.__str__())



    def equals(self, another_qrcode):
        """
        Checks if another QRCode instance is equal to this one, based on data and error correction level.

        Args:
            another_qrcode (QRCode): Another QRCode instance to compare with.

        Returns:
            bool: True if both QR codes are identical in data and error correction, otherwise False.

        Example:
            >>> qr1 = QRCode("qr_data1.txt", "15/04/2021", "Alice", 0.1)
            >>> qr2 = QRCode("qr_data2.txt", "15/04/2021", "Alice", 0.1)
            >>> qr1.equals(qr2)
            False
        """

        if another_qrcode is not None:
            return self.data.equals(another_qrcode.data) and self.error_correction == another_qrcode.error_correction

        raise ValueError("Can't compare to Null QRCode")



    def is_corrupted(self, precise_qrcode):
        """
        Determines if the QR code is corrupted by comparing it with a precise QR code.

        Args:
            precise_qrcode (QRCode): A QRCode instance representing the expected accurate QR code.

        Returns:
            bool: True if the QR code is corrupted beyond the error tolerance, otherwise False.

        Example:
            >>> precise_qr = QRCode("precise_data.txt", "10/05/2023", "Alice", 0.05)
            >>> qr = QRCode("qr_data.txt", "10/05/2023", "Alice", 0.05)
            >>> qr.is_corrupted(precise_qr)
            False
        """

        if precise_qrcode is not None:
            return not self.data.approximately_equals(precise_qrcode.data, self.error_correction)

        raise ValueError("Can't compare to Null QRCode")

