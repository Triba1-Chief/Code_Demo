def convert_date(data_str):
    """
    Converts a date string in the format "DD/MM/YYYY" into a dictionary with day, month, and year as keys.

    Args:
        data_str (str): A date string in the format "DD/MM/YYYY".

    Returns:
        dict: A dictionary with keys "Day", "Month", and "Year" representing the date.

    Raises:
        ValueError: If the input date string is not in the correct format.

    Example:
        >>> convert_date("12/08/2023")
        {'Day': '12', 'Month': '08', 'Year': '2023'}

        >>> convert_date("5/11/2022")
        ValueError: Input format incorrect!
    """

    calendar = {}
    data = data_str.split('/')

    if len(data) == 3:
        if len(data[0]) != 2 or len(data[1]) != 2 or len(data[2]) != 4:
            raise ValueError("Input format incorrect!")

        calendar = {"Day": data[0], "Month": data[1], "Year": data[2]}
        return calendar

    raise ValueError("Input format incorrect!")



def get_data(file_path):
    """
    Reads a file containing 0s and 1s to create a nested list representation of the data.

    Args:
        file_path (str): Path to the file containing the data.

    Returns:
        list: A nested list of integers, where each inner list represents a row of 0s and 1s from the file.

    Raises:
        ValueError: If the file contains characters other than 0 and 1.

    Example:
        # Assuming "data.txt" contains:
        # 101
        # 010
        # 111
        >>> get_data("data.txt")
        [[1, 0, 1], [0, 1, 0], [1, 1, 1]]

        # Assuming "data_invalid.txt" contains:
        # 12
        # 010
        >>> get_data("data_invalid.txt")
        ValueError: File should contain only 0s and 1s!
    """

    nestedList = []
    counter = 0

    fobj = open(file_path, 'r')

    for data in fobj:
        nestedList.append([])  # Creates the inner list
        for num in data.strip('\n'):
            if num != "0" and num != "1":
                raise ValueError("File should contain only 0s and 1s!")
            nestedList[counter].append(int(num))
        counter += 1  # Moves to the next nested list

    fobj.close()
    return nestedList