from copy import deepcopy
from Python.QRCode_builder.helper import *



class TxtData:
    """
    A class representing data for a QR code, stored as a 2D list with various utility methods.

    Attributes:
        data (list): A deep copy of the provided 2D list representing QR code data.
        rows (int): The number of rows in the 2D data.
        cols (int): The number of columns in the 2D data.
    """

    def __init__(self, data):
        """
        Initializes a TxtData object with the provided data.

        Args:
            data (list): A 2D list of integers representing the QR code data.

        Example:
            >>> data = [[1, 0, 1], [0, 1, 0], [1, 0, 1]]
            >>> txt_data = TxtData(data)
            >>> print(txt_data.rows, txt_data.cols)
            3 3
        """

        self.data = deepcopy(data)
        self.rows = len(self.data)
        self.cols = len(self.data[0])



    def __str__(self):
        """
        Returns a string representation of the TxtData object's dimensions.

        Returns:
            str: Description of rows and columns in the TxtData object.

        Example:
            >>> data = [[1, 0], [0, 1]]
            >>> txt_data = TxtData(data)
            >>> print(txt_data)
            This TxtData object has 2 rows and 2 columns.
        """

        return "This TxtData object has " + str(self.rows) + " rows and " + str(self.cols) + " columns."



    def get_pixels(self):
        """
        Calculates the total number of pixels in the data.

        Returns:
            int: Total number of pixels (rows * columns).

        Example:
            >>> data = [[1, 0], [0, 1]]
            >>> txt_data = TxtData(data)
            >>> txt_data.get_pixels()
            4
        """

        return self.rows * self.cols



    def get_data_at(self, row, column):
        """
        Retrieves the value at a specific row and column in the data.

        Args:
            row (int): Row index.
            column (int): Column index.

        Returns:
            int: The data value at the specified row and column.

        Raises:
            ValueError: If the row or column index is out of bounds.

        Example:
            >>> data = [[1, 0], [0, 1]]
            >>> txt_data = TxtData(data)
            >>> txt_data.get_data_at(0, 1)
            0
        """

        if  0 <= row < self.rows and 0 <= column < self.cols:
            return self.data[row][column]
        raise ValueError("Index out of bound!")



    def pretty_save(self, file_name):
        """
        Saves the QR code data to a file in a readable format.

        "1" values are converted to the block character (U+2588), while "0" values are saved as two spaces.

        Args:
            file_name (str): Name of the file to save the formatted data.

        Example:
            >>> data = [[1, 0], [0, 1]]
            >>> txt_data = TxtData(data)
            >>> txt_data.pretty_save("output.txt")
        """

        fobj = open(file_name, "w", encoding="utf-8")  # Specify encoding to handle block character on Windows
        for row in self.data:
            line = ""
            for col in range(len(row)):
                if row[col] == 1:
                    line += "\u2588" * 2
                else:
                    line += "  "
            fobj.write(line + "\n")
        fobj.close()



    def equals(self, another_data):
        """
        Checks if the current data is equal to another TxtData instance.

        Args:
            another_data (TxtData): Another TxtData instance to compare.

        Returns:
            bool: True if the data, rows, and columns are the same, False otherwise.

        Example:
            >>> data1 = [[1, 0], [0, 1]]
            >>> data2 = [[1, 0], [0, 1]]
            >>> txt_data1 = TxtData(data1)
            >>> txt_data2 = TxtData(data2)
            >>> txt_data1.equals(txt_data2)
            True
        """

        return self.rows == another_data.rows and self.cols == another_data.cols and self.data == another_data.data



    def approximately_equals(self, another_data, precision):
        """
        Checks if the current data is approximately equal to another TxtData instance.

        Compares each element, and if the difference ratio is within the precision threshold, returns True.

        Args:
            another_data (TxtData): Another TxtData instance to compare.
            precision (float): Allowed precision level as a float (e.g., 0.1 allows 10% mismatches).

        Returns:
            bool: True if the difference ratio is within the specified precision, False otherwise.

        Raises:
            ValueError: If precision is negative.

        Example:
            >>> data1 = [[1, 0], [0, 1]]
            >>> data2 = [[1, 0], [1, 1]]
            >>> txt_data1 = TxtData(data1)
            >>> txt_data2 = TxtData(data2)
            >>> txt_data1.approximately_equals(txt_data2, 0.25)
            True
        """

        if precision < 0:
            raise ValueError("Precision must be greater than 0!")
        if another_data.rows != self.rows or another_data.cols != self.cols: #Don't have similar dimensions
            return False

        counter = 0
        for row in range(len(self.data)):
            for col in range(len(self.data[row])):
                if self.data[row][col] != another_data.data[row][col]:
                    counter += 1
        return not (counter / self.get_pixels() > precision)