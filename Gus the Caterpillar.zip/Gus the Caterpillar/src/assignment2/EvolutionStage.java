package assignment2;

public enum EvolutionStage {
	ENTANGLED,
	FEEDING_STAGE,
	GROWING_STAGE,
	BUTTERFLY
}
