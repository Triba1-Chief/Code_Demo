package assignment2;

import java.awt.Color;
import java.util.Random;
import java.util.Stack;

import assignment2.food.*;


/* Assumptions made:
1. Gus will always move before attempting to eat
2. Gus will eat only when it is in a feeding stage
3. Null is not a valid input for any method.
 */


public class Caterpillar {
	// All the fields have been declared public for testing purposes
	// About Gus:
	public Segment head; // head segment of Gus
	public Segment tail; // tail segment of Gus
	public int length; // no of segments of Gus
	public EvolutionStage stage; //stage of development of Gus

	// Behaviour of Gus
	public Stack<Position> positionsPreviouslyOccupied; //all positions previously occupied by Gus {most recent - right}
	public int goal; //number of segments left to become a butterfly
	public int turnsNeededToDigest; //number 0f turns left before Gus can eat again

	//Generate random numbers: look at guideline of how to use
	public static Random randNumGenerator = new Random(1);



	// Creates a Caterpillar with one Segment. It is up to students to decide how to implement this.
	//head and tail are considered one segment at the start.
	public Caterpillar(Position p, Color c, int goal) {
		this.head = new Segment(p,c);
		this.tail = this.head;
		this.length++;
		this.stage = EvolutionStage.FEEDING_STAGE;
		this.goal = goal;
		this.positionsPreviouslyOccupied = new Stack<Position>();
	}

	
	public EvolutionStage getEvolutionStage() {
		return this.stage;
	}

	public Position getHeadPosition() {
		return this.head.position;
	}

	public int getLength() {
		return this.length;
	}


	// returns the color of the segment in position p. Returns null if such segment does not exist
	public Color getSegmentColor(Position p) {
		Segment current = head;

		for (int i = 0; i < this.getLength(); i++) {
			if (current.position.equals(p)) {
				return current.color;
			}
			else {
				current = current.next;
			}
		}

		return null;
	}


	// shift all Segments to the previous Position while maintaining the old color
	public void move(Position p) {
		if(this.getEvolutionStage() == EvolutionStage.ENTANGLED) {//Ensures no movement even with prior entanglement
			return;
		}

		//Checks if we are within range of movement
		double range = Position.getDistance(new Position(this.getHeadPosition()), new Position(p));
		if (range != 1) {
			throw new IllegalArgumentException();
		}


		//Shift colours upwards after moving
		Segment newHead = new Segment(p, this.head.color);
		newHead.next = this.head;
		this.head = newHead;

		Segment current = this.head.next;
		Segment previous = this.head;
		int i = 0;
		while (i < this.getLength()) {
			if (current.next != null) {
				current.color = current.next.color;
				previous = current;
				current = current.next;
			} else {
				//Disconnects the previous tail.
				this.positionsPreviouslyOccupied.push(current.position);
				this.tail = previous;
				previous.next = null;
			}

			i++;
		}


		//Checks if a segment is in the position
		Segment currentPosition = this.head.next;

		while (currentPosition != null) {
			if (this.getHeadPosition().equals(this.tail.position) || currentPosition.position.equals(p)) {
				this.stage = EvolutionStage.ENTANGLED;
				return;
			}

			currentPosition = currentPosition.next;
		}


		//Digesting the cake/fruit further one movement at a time
		if (this.getEvolutionStage() != EvolutionStage.FEEDING_STAGE) {
			if (this.getEvolutionStage() == EvolutionStage.BUTTERFLY || this.getEvolutionStage() == EvolutionStage.ENTANGLED) {
				return;
			}

			if (this.turnsNeededToDigest == 0) {
				this.stage = EvolutionStage.FEEDING_STAGE;
			}
			else {
				if (this.turnsNeededToDigest > 0) {
					Segment newTail;
					currentPosition = this.head;
					Position compare = this.positionsPreviouslyOccupied.pop();

					//Ensures that position being added is not in the stack
					while (currentPosition != null) {
						if (!(compare.equals(currentPosition.position))) {
							currentPosition = currentPosition.next;
						}
						else {
							this.positionsPreviouslyOccupied.push(compare);
							return;
						}
					}

					int k = randNumGenerator.nextInt(GameColors.SEGMENT_COLORS.length);

					newTail = new Segment(compare,GameColors.SEGMENT_COLORS[k]);
					this.tail.next = newTail;
					this.tail = newTail;
					this.length++;

					if (this.getLength() >= this.goal) {
						this.stage = EvolutionStage.BUTTERFLY;
						return;
					}

					this.turnsNeededToDigest--;
				}
			}
		}
	}



	// a segment of the fruit's color is added at the end
	public void eat(Fruit f) {
		if(this.getEvolutionStage() == EvolutionStage.BUTTERFLY || this.getEvolutionStage() == EvolutionStage.ENTANGLED) {
			return;
		}


		Color fruitColour = f.getColor();
		Segment newTail;
		Position prevPosition = this.positionsPreviouslyOccupied.pop();

		if (!(this.getHeadPosition().equals(prevPosition))) {
			newTail = new Segment(prevPosition, fruitColour);

			if (this.tail == this.head) {
				this.head.next = newTail;
			}
			else {
				this.tail.next = newTail;
			}

			this.tail = newTail;
			this.length++;

			if (this.getLength() >= this.goal) {
				this.stage = EvolutionStage.BUTTERFLY;
			}
		}
		else {
			this.stage = EvolutionStage.GROWING_STAGE;
			this.turnsNeededToDigest++;
			this.positionsPreviouslyOccupied.push(prevPosition);
		}
	}



	// the caterpillar moves one step backwards because of sourness
	public void eat(Pickle p) {
		if(this.getEvolutionStage() != EvolutionStage.FEEDING_STAGE) {
			return;
		}


		Segment current = this.head;
		int i = 0;

		//Updating the colour downwards
		while (i < this.getLength()) {
			if (current.next != null) {
				current.position = current.next.position;
				current = current.next;
			}
			else {
				this.tail.position = this.positionsPreviouslyOccupied.pop();
			}

			i++;
		}
	}


	// all the caterpillar's colors shuffles around
	public void eat(Lollipop lolly) {
		if(this.getEvolutionStage() != EvolutionStage.FEEDING_STAGE) {
			return;
		}


		Color[] colorsArray = new Color[this.getLength()];
		Segment current = this.head;

		//Copy of colours
		for (int i = 0; i < this.getLength(); i++) {
			colorsArray[i] = getSegmentColor(current.position);
			current = current.next;
		}

		//Shuffling colours
		for (int i = colorsArray.length - 1; i > 0; i-- ) {
			int j = randNumGenerator.nextInt(i + 1); //[0,1]

			//Swap colors
			Color temp = colorsArray[i];
			colorsArray[i] = colorsArray[j];
			colorsArray[j] = temp;
		}

		//Updating segment colours
		current = this.head;
		for (int i = 0; i < this.getLength(); i++) {
			current.color = colorsArray[i];
			current = current.next;
		}

	}


	// brain freeze!!
	// It reverses and its (new) head turns blue
	public void eat(IceCream gelato) {
		if(this.getEvolutionStage() != EvolutionStage.FEEDING_STAGE) {
			return;
		}


		//Store the segments in an array for reversal
		Segment current = this.head;
		Segment[] segmentsArray = new Segment[this.getLength()];

		for (int i = 0; i < this.getLength(); i++) {
			segmentsArray[i] = current;
			current = current.next;
		}

		//Reversing the order segments
		for (int i = segmentsArray.length - 1; i > 0; i--) {
			segmentsArray[i].next = segmentsArray[i - 1];
		}

		this.head = segmentsArray[segmentsArray.length - 1];
		this.head.color = GameColors.BLUE;
		this.tail = segmentsArray[0];
		this.tail.next = null;
		this.positionsPreviouslyOccupied.clear();

	}



	// the caterpillar embodies a slide of Swiss cheese loosing half of its segments. 
	public void eat(SwissCheese cheese) {
		if(this.getEvolutionStage() != EvolutionStage.FEEDING_STAGE) {
			return;
		}


		Segment [] tempSegments = new Segment[this.getLength()];
		Segment current = this.head;
		int counter = 0;
		int halfway = (this.getLength() + 1)/2;

		//Getting the new tail and positions to push onto the stack
		for (int i = 0; i < this.getLength(); i++) {
			//Caters for the colour change of the first two segments
			if ((i+1) <= halfway) {
				//Halfway point becomes the new tail no matter the number of segments
				if ((i + 1) == halfway) {
					this.tail = current;
				}

				if (current.equals(this.head)) { //head retains color
					current = current.next;
					continue;
				}

				if (current.equals((this.head.next))) { //head.next gets color of adjacent segment
						current.color = getSegmentColor(current.next.position);
				}
				else {
					// The rest of the segments get the colors of the segments 2 steps down.
					if (current.next.next != null) {
						current.color = getSegmentColor(current.next.next.position);
					}
				}

			}
			else { //Pushing the positions of the rest of the segments onto the stack
				tempSegments[counter] = current;
				counter++;
			}

			current = current.next;
		}

		this.tail.next = null; //Disconnects the segments past the halfway point
		this.length = halfway; //Update the length

		while (counter != 0) {
			this.positionsPreviouslyOccupied.push(tempSegments[(counter - 1)].position);
			counter--;
		}
	}



	public void eat(Cake cake) {
		if(this.getEvolutionStage() != EvolutionStage.FEEDING_STAGE) {
			return;
		}


		int cakeEnergy = cake.getEnergyProvided();
		int growthFactor = 0;
		Segment current = this.head;
		Segment newTail;
		boolean similar = false;// marks similarity between position on stack and segment
		int size = this.positionsPreviouslyOccupied.size();
		this.stage = EvolutionStage.GROWING_STAGE;

		//Check if positions on the segment are on the stack. If not a new segment is added.
		for (int i = 0; i < cakeEnergy && size > 0; i++) {
			for (int j = 0; j < this.getLength(); j++) {
				if (!(this.positionsPreviouslyOccupied.elementAt(size - 1).equals(current.position))){
					current = current.next;
				}
				else {
					similar = true;
					break;
				}
			}
			//If a similarity is found, no more segments are added
			if (similar) {
				break;
			}

			//adds the segment
			int k = randNumGenerator.nextInt(GameColors.SEGMENT_COLORS.length);
			newTail = new Segment(this.positionsPreviouslyOccupied.pop(),GameColors.SEGMENT_COLORS[k]);
			size--;
			this.tail.next = newTail;
			this.tail = newTail;
			this.length++;
			if (this.getLength() >= this.goal) { //Checks if caterpillar has met its goal
				this.stage = EvolutionStage.BUTTERFLY;
				return;
			}
			growthFactor++;
			current = this.head;
		}

		//Growth stage evaluation
		this.turnsNeededToDigest = cakeEnergy - growthFactor;

	}



	// This nested class was declared public for testing purposes
	public class Segment { //Segment Constructor
		private Position position; //position of each segment (x,y)
		private Color color; //colour of each segment depending on what Gus ate
		private Segment next; //next segment. if last -> null

		public Segment(Position p, Color c) {
			this.position = p;
			this.color = c;
		}

	}


	public String toString() { //returns position: tail on the most left and head on the most right
		Segment s = this.head;
		String gus = "";
		while (s!=null) {
			String coloredPosition = GameColors.colorToANSIColor(s.color) + 
					s.position.toString() + GameColors.colorToANSIColor(Color.WHITE);
			gus = coloredPosition + " " + gus;
			s = s.next;
		}
		return gus;
	}
}