#This program will find words in a list of letters. Once all the words are
#found in the list, the program will search for free letters in the list
#sequentially. These letters will constitute the mystery word.

#CONSTANTS
LEFT = -1 #right to left
RIGHT = 1 #left to right
POSSIBLE_DIRECTIONS = LEFT, RIGHT 
FIRST_LETTER = 0 #index of the first letter in a word


#Functions
#1. Valid index function
def is_outside_list(letter_list, integer):
    """
        (list, integer) -> (Boolean)
        
        The function indicates whether the index is out of bounds with regards
        to the length of the list by returning True if out of bound and false if
        otherwise.
        
        >>> is_outside_list(['A','B','C','D'], 4)
        True
        >>> is_outside_list(['A','B','C','D'], 2)
        False
        >>> is_outside_list(['A','B','C','D'], -69)
        True
    """
    
    if integer < 0 and integer > (len(letter_list) - 1):
        return True
    else:
        return False


#2. Letter position function
def letter_positions(letter_list, character):
    """
        (list, string) -> (list)
        
        The function looks for all the positive indices where the given
        character is found and returns a list of the indices. It returns an
        empty string if no indices are found.
        
        >>> letter_positions(['A','B','C','D'], 'z')
        []
        >>> letter_positions(['A','B','C','D'], 0)
        []
        >>> letter_positions(['C','B','C','C'], 'C')
        [0, 2, 3]
    """
    
    position_list = []
    
    for index in range(len(letter_list)):
        if letter_list[index] == character:
            position_list.append(index)
    return position_list


#3. Valid position given direction function
def valid_word_pos_direction(letter_list, word, index, direction):
    """
        (list, string, integer, integer) -> (Boolean)
        
        The function will return True if a word is found at a specific location
        in a specified direction and False if otherwise.
        
        >>> valid_word_pos_direction(['A','B','C','D','C','M'], 'CDC', 3, 1)
        False
        >>> valid_word_pos_direction(['A','B','C','D','C','M'], 'DCB', 3, -1)
        True
        >>> valid_word_pos_direction(['A','B','C','D','C'], 'BCD', 5, -1)
        False
    """ 
    for i in range(len(word)):
        if letter_list[index] == word[i] and not is_outside_list(letter_list, index):
            index = index + direction 
        else:
            return False
            
    return True
    
                        
#4. Direction of word function
def direction_word_given_position(letter_list, word, index):
    """
        (list, string, integer) -> (list)
        
        The function validates if the first letter of the word is found at the
        given index in the list of letters and searches in both directions to
        find the given word.
        
        >>> direction_word_given_position(['A','B','C','D','C','M'], 'DC', 3)
        [-1, 1]
        >>> direction_word_given_position(['A','B','A','D','C','B'], 'AB', 1)
        []
        >>> direction_word_given_position(['A','B','C','D','C','M'], 'MC', 5)
        [-1]
    """
    
    list_directions = []
    
    if word[FIRST_LETTER] == letter_list[index]:
        for direction in POSSIBLE_DIRECTIONS:
            if valid_word_pos_direction(letter_list, word, index, direction):
                list_directions.append(direction)
    return list_directions


#5. Position:direction dictionary function
def position_direction_word(letter_list, word):
    """
        (list, string) -> (dictionary)
        
        The function returns a dictionary of positions(key) and
        directions(elements) of a word in a list of letters. 
        
        >>> position_direction_word(['A','B','C','D','C','M'], 'PX')
        {}
        >>> position_direction_word(['B','A','K','C','A','B'], 'BACK')
        {5: [-1]}
        >>> position_direction_word(['A','B','C','D','C','M'], 'DC')
        {3: [-1, 1]}
    """
    
    dict_position_direction = {}
    
    for position in letter_positions(letter_list, word[FIRST_LETTER]):
        if not direction_word_given_position(letter_list, word, position) == []:
            dict_position_direction[position] = (direction_word_given_position
                                                 (letter_list, word, position))
    return dict_position_direction


#6. Cross word function
def cross_word_position_direction(letter_list, word, index, direction):
    """
        (list, string, integer, integer) -> ()
        
        The function replaces each letter of the word found at the indicated
        index and direction by the star symbol "*”.
        
        >>> cross_word_position_direction(['A','B','C','A','B','C'], 'ABC',0, 1)
        ['*', '*', '*', 'A', 'B', 'C']
        >>> cross_word_position_direction(['A','B','C','A','B','C'], 'AB', 0, 1)
        ['*', '*', 'C', 'A', 'B', 'C']
        >>> cross_word_position_direction(['B','C','A','C','C'], 'AC', 2, -1)
        ['B', '*', '*', 'C', 'C']
    """
    
# Generating the indices of the letters to be replaced
    for i in range(len(word)):
        if direction == RIGHT:
            letter_list[index + i] = '*'     
        else:
            letter_list[index - i] = '*'


#7. Cross all words function
def cross_word_all_position_direction(letter_list,word,dict_position_direction):
    """
        (list, string, dictionary) -> ()
        
        The function replaces each letter of the word found at the indicated
        indices and directions by the star symbol ”*”.
        
        >>> cross_word_all_position_direction(['A','B','C','D'], 'AB', {0:[1]})
        ['*', '*', 'C', 'D']
        >>> cross_word_all_position_direction(['C','D','C'], 'DC', {1:[-1, 1]})
        ['*', '*', '*']
        >>> cross_word_all_position_direction(['K','C','K'],'KC',{0:[1],2:[-1]})
        ['*', '*', '*']
    """

    for position in dict_position_direction:
        for direction in dict_position_direction[position]:
            (cross_word_position_direction
             (letter_list, word, position, direction))
            

#8. Magic word function
def find_magic_word(letter_list):
    """
        (list) -> (string)
        
        The function goes through a list of letters to find the hidden word. If
        no word is found, the hidden word becomes an empty string
        
        >>> find_magic_word(['*', '*', 'C', 'D'])
        'CD'
        >>> find_magic_word(['*', '*', '*'])
        ''
        >>> find_magic_word(['B', '*', 'A', '*', 'D'])
        'BAD'
    """
    
    hidden_word = ""
    
    for char in letter_list:
        if char != '*':
            hidden_word += char
    return hidden_word
 

#9. word search function
def word_search(letter_list, word_list):
    """
        (list, list) -> (string)
        
        This function goes through each word in the list of words to cross them
        out in the list of letters. It will then return the magic word.
        
        >>> word_search(['A', 'B', 'C', 'D'], ['A', 'B'])
        'CD'
        >>> word_search(['S', 'A', 'D'], ['C', 'M'])
        'SAD'
        >>> word_search(['B', 'A', 'T', 'A', 'G', 'O', 'D'], ['BAT', 'A'])
        'GOD'
    """
    magic_word = ""
    
    for word in word_list:
        dict_position_direction = position_direction_word(letter_list, word)
        (cross_word_all_position_direction
         (letter_list,word,dict_position_direction))
        magic_word = find_magic_word(letter_list)
    return magic_word
    

#10. word search main program function
def word_search_main(filepath):
    """
        (string) -> (string)
        
        The function reads the given input file and returns the magic word.
        
        >>> word_search_main('word_search.py')
        'PYTHON'
        >>> word_search_main(wordsearch.py)
        NameError: name 'wordsearch' is not defined
        >>> word_search_main(word_search.py)
        AttributeError: 'function' object has no attribute 'py'
    """
    
    read_data = [] #holds data from the file as list
    letter_list = []
    word_list = []
    new_word = ""
    
    fobj = open(filepath,'r')
    
    for line in fobj:
        read_data += [line]
        
    for letter in read_data[0]:
        if not letter == " " and not letter == '\n':
            letter_list += letter.upper()
    
    for word in read_data[1:]:   
        if word != '\n': #Only process words and skips blank lines
            for char in word:
                if not char == " " and not char == '\n':
                    new_word += char.upper()
                    
            if new_word != "": #Prevents blanks from being added to word_list
                word_list += [new_word]
                new_word = ""
       
    fobj.close()
    
    magic_word = word_search(letter_list, word_list)
    return magic_word
