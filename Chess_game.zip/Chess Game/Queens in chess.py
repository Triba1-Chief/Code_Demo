def check_queens(board):
    """ Returns True iff the two queens on board attack each other. """

    queen_position = [] #positions of queens on the board
    rankindex = 0  # Keeps track of the current row
    counter = 0  # Counter for the number of queens in a row

    # Loop through each row in the board, get queen positions and check attack on same row
    for rank in board:
        for file in range(len(rank)):
            if rank[file] == 1:  # If there's a queen in this position
                counter += 1
                queen_position.append([rankindex,file])  # Record the position of the queen
                
            if counter == 2:  # If two queens are found in the same row, they attack
                return True

        rankindex += 1
        counter = 0  # Reset counter for the next row
    
    
    if len(queen_position) > 1:
        # Check if the queens attack each other diagonally or in the same column
        for currpos in range(len(queen_position)):
            for nextpos in range(currpos + 1, len(queen_position)):
                if (queen_position[currpos][1] == queen_position[nextpos][1] or
                        abs(queen_position[currpos][0] - queen_position[nextpos][0]) ==
                        abs(queen_position[currpos][1] - queen_position[nextpos][1])) :
                    return True
            
    return False  # No queens attack each other


if __name__ == "__main__":
    # Test board configurations
    boardA = [[0, 0, 0, 0, 0, 0, 0, 0],  
              [0, 0, 0, 0, 0, 0, 0, 0],
              [1, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0]]
    
    print(check_queens(boardA))  # False: One queen, no attacks

    boardB = [[0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 1, 0, 0, 0],  # A queen is at (2, 4)
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 1, 0, 0, 0, 0, 0, 0],  # A queen is at (5, 1)
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0]]
    
    print(check_queens(boardB))  # True: Queens attack diagonally

    boardC = [[0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 1, 0, 0, 0],  # A queen is at (2, 4)
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 1, 0, 0, 0],  # Another queen at (6, 4)
              [0, 0, 0, 0, 0, 0, 0, 0]]
    
    print(check_queens(boardC))  # True: Queens in the same column attack

    boardD = [[0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 1],  # A queen is at (6, 7)
              [1, 0, 0, 0, 0, 0, 0, 0]]  # Another queen at (7, 0)
    
    print(check_queens(boardD))  # False: No attacks

    boardE = [[0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 1, 1, 0, 0, 0, 0],  #Queens at (2,2) and (2,3)
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0]]
    
    print(check_queens(boardE))  # True: Attack