package finalproject;

import java.util.ArrayList;
import java.util.Arrays;


import finalproject.system.Tile;

public class TilePriorityQ {
	// TODO level 3: Add fields that can help you implement this data type
	int size;
	Tile[] heaplist;


	private void downHeap (int startIndex, int maxIndex) {
		int k = startIndex;

		while (2 * k <= maxIndex) {
			int child  =  2 * k;

			if (child < maxIndex) {
				if (heaplist[child + 1].costEstimate < heaplist[child].costEstimate) {
					child = child + 1;
				}
			}

			//Swapping two elements in the heap
			if (heaplist[child].costEstimate < heaplist[k].costEstimate) {
				Tile temp = heaplist[child];
				heaplist[child] = heaplist[k];
				heaplist[k] = temp;
				k = child;
			}
			else {
				break;
			}
		}
	}



	private void upHeap(int index) {
		while (index > 1) {
			int parentIndex = index / 2;

			if (heaplist[index].costEstimate < heaplist[parentIndex].costEstimate) {
				// Swap the current element with its parent
				Tile temp = heaplist[index];
				heaplist[index] = heaplist[parentIndex];
				heaplist[parentIndex] = temp;

				// Move up to the parent index
				index = parentIndex;
			} else {
				// Stop if the min-heap property is satisfied
				break;
			}
		}
	}




	// TODO level 3: implement the constructor for the priority queue
	public TilePriorityQ (ArrayList<Tile> vertices) {
		this.heaplist = new Tile[vertices.size() + 1];
		this.size = vertices.size();

		for (int i = 0; i < vertices.size(); i++) {
			heaplist[i+1] = vertices.get(i);
			upHeap(i);
		}
	}


	
	// TODO level 3: implement remove min as seen in class
	public Tile removeMin() {
		if (size > 0) {
			Tile temp = heaplist[1];
			heaplist[1] = heaplist[size];
			size = size - 1;
			downHeap(1, size);
			return temp;
		}
		return null;
	}


	
	// TODO level 3: implement updateKeys as described in the pdf
	public void updateKeys(Tile t, Tile newPred, double newEstimate) {
		for (int i = 1; i<= size; i++) {
			if (heaplist[i].equals(t)) {
				t.predecessor = newPred;
				t.costEstimate = newEstimate;

				upHeap(i);
				downHeap(1, size);
				break;
			}
		}
	}
	
}