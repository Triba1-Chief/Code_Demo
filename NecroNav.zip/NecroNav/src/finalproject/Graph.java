package finalproject;

import java.util.ArrayList;
import java.util.HashSet;

import finalproject.system.Tile;
import finalproject.system.TileType;
import finalproject.tiles.*;

public class Graph {
	// TODO level 2: Add fields that can help you implement this data type
    ArrayList<Tile> vertices;
    ArrayList<Edge> edges;

    // TODO level 2: initialize and assign all variables inside the constructor
	public Graph(ArrayList<Tile> vertices) {
		this.vertices = vertices;
        this.edges = new ArrayList<Edge>();
	}
	
    // TODO level 2: add an edge to the graph
    public void addEdge(Tile origin, Tile destination, double weight){
        if (this.vertices.contains(origin) && this.vertices.contains(destination)) {
            this.edges.add(new Edge(origin, destination, weight));
        }
    }
    
    // TODO level 2: return a list of all edges in the graph
	public ArrayList<Edge> getAllEdges() {
		return this.edges;
	}
  
	// TODO level 2: return list of tiles adjacent to t
	public ArrayList<Tile> getNeighbors(Tile t) {
        ArrayList<Tile> neighbors = new ArrayList<Tile>();

        if (this.vertices.contains(t)) {
            for (Edge edge : edges) {
                if (edge.getStart().equals(t)) {
                    neighbors.add(edge.getEnd());
                }
            }
        }

        return neighbors;
    }
	
	// TODO level 2: return total cost for the input path
	public double computePathCost(ArrayList<Tile> path) {
		double counter = 0;

        for (int i = 0; i < path.size() - 1; i++) {
            //finding the edge that connect the two vertices
            for (Edge edge : edges) {
                if (edge.getStart().equals(path.get(i)) && edge.getEnd().equals(path.get(i+1))) {
                    counter += edge.weight;
                    break;
                }
            }
        }

        return counter;
	}
	
   
    public static class Edge{
    	Tile origin;
    	Tile destination;
    	double weight;


        // TODO level 2: initialize appropriate fields
        public Edge(Tile s, Tile d, double cost){
            this.origin = s;
            this.destination = d;
        	this.weight = cost;
        }
        
        // TODO level 2: getter function 1
        public Tile getStart(){
            return this.origin;
        }

        
        // TODO level 2: getter function 2
        public Tile getEnd() {
            return this.destination;
        }
        
    }
    
}