package finalproject;

import finalproject.system.Tile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

public abstract class PathFindingService {
	Tile source;
	Graph g;
	
	public PathFindingService(Tile start) {
    	this.source = start;
    }

	public abstract void generateGraph();
    
    //TODO level 4: Implement basic dijkstra's algorithm to find a path to the final unknown destination
    public ArrayList<Tile> findPath(Tile startNode) {
        ArrayList<Tile> generatedPath = new ArrayList<Tile>();

        if (g.vertices.contains(startNode)) {
            //Initializing single source
            for (Tile tile : g.vertices) {
                tile.costEstimate = Double.POSITIVE_INFINITY;
                tile.predecessor = null;
            }

            startNode.costEstimate = 0;

            TilePriorityQ minheap = new TilePriorityQ(g.vertices);

            while (minheap.size != 0) {
                Tile temp = minheap.removeMin();

                //Relaxing
                for (Tile tile : g.getNeighbors(temp)) {
                    if (tile.costEstimate > temp.costEstimate + findWeight(temp, tile)) {
                        tile.costEstimate = temp.costEstimate + findWeight(temp, tile);
                        tile.predecessor = temp;
                        minheap.updateKeys(tile, tile.predecessor, tile.costEstimate);

                    }
                }
            }

            //Backtrack to find the path
            for (Tile tile : g.vertices) {
                if (tile.isDestination) {
                    Tile cur = tile;

                    while (cur != null) {
                        generatedPath.add(cur);
                        cur = cur.predecessor;
                    }

                    break;
                }
            }

            //Reverse the order of the path
            int sIndex = 0;
            int eIndex = generatedPath.size() - 1;

            while (sIndex < eIndex) {
                // Swap elements at sIndex and eIndex
                Tile temp = generatedPath.get(sIndex);
                generatedPath.set(sIndex, generatedPath.get(eIndex));
                generatedPath.set(eIndex, temp);

                // Move indices towards the center
                sIndex++;
                eIndex--;
            }
        }

        return generatedPath;
    }


    
    //TODO level 5: Implement basic dijkstra's algorithm to path find to a known destination
    public ArrayList<Tile> findPath(Tile start, Tile end) {
        ArrayList<Tile> generatedPath = new ArrayList<Tile>();

        if (g.vertices.contains(start) && g.vertices.contains(end)) {
            //Initializing single source
            for (Tile tile : g.vertices) {
                tile.costEstimate = Double.POSITIVE_INFINITY;
                tile.predecessor = null;
            }

            start.costEstimate = 0;

            TilePriorityQ minheap = new TilePriorityQ(g.vertices);

            //implementing the minheap
            while (minheap.size != 0) {
                Tile temp = minheap.removeMin();

                //Relaxing
                for (Tile tile : g.getNeighbors(temp)) {
                    if (tile.costEstimate > temp.costEstimate + findWeight(temp, tile)) {
                        tile.costEstimate = temp.costEstimate + findWeight(temp, tile);
                        tile.predecessor = temp;
                        minheap.updateKeys(tile, tile.predecessor, tile.costEstimate);

                    }
                }
            }

            //Backtrack to find the path
            Tile cur = end;
            while (cur != null) {
                generatedPath.add(cur);
                cur = cur.predecessor;
            }

            //Reverse the order of the path
            int sIndex = 0;
            int eIndex = generatedPath.size() - 1;

            while (sIndex < eIndex) {
                // Swap elements at sIndex and eIndex
                Tile temp = generatedPath.get(sIndex);
                generatedPath.set(sIndex, generatedPath.get(eIndex));
                generatedPath.set(eIndex, temp);

                // Move indices towards the center
                sIndex++;
                eIndex--;
            }
        }

        return generatedPath;
    }



    //TODO level 5: Implement basic dijkstra's algorithm to path find to the final destination passing through given waypoints
    public ArrayList<Tile> findPath(Tile start, LinkedList<Tile> waypoints){
        ArrayList<Tile> generatedPath = new ArrayList<Tile>();

    	if (g.vertices.contains(start) && waypoints != null) {
            Tile temp = start;

            for (Tile tile : waypoints) {
                if (g.vertices.contains(tile)) {
                    if (!tile.isDestination) {
                        ArrayList<Tile> tempPath = findPath(temp, tile);

                        //removing redundant element
                        if (!tempPath.isEmpty()) {
                            tempPath.remove(tile);
                        }

                        generatedPath.addAll(tempPath);
                    }

                    temp = tile; //this is the destination

                }
                else {
                    return null;
                }
            }

            generatedPath.addAll(findPath(temp));
        }

        return  generatedPath;
    }



    //Returns the weight of the edge joining two points
    private double findWeight (Tile nSource, Tile destination) {
        for (int i = 0; i < g.edges.size(); i++) {
            if (g.edges.get(i).getStart().equals(nSource) && g.edges.get(i).getEnd().equals(destination)) {
                return g.edges.get(i).weight;
            }
        }

        return 0;
    }
}

