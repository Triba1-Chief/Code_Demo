package finalproject;

import finalproject.system.Tile;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;

public class GraphTraversal
{


	//TODO level 1: implement BFS traversal starting from s
	public static ArrayList<Tile> BFS(Tile s) {
		ArrayList<Tile> BFSlist = new ArrayList<Tile>();
		LinkedList<Tile> templist = new LinkedList<Tile>();

		if (s != null) { //ensures it is a valid tile
			s.isStart = true;
			templist.addLast(s); //enqueue tile list


			//Traversing the graph
			while (!templist.isEmpty()) {
				Tile cur = templist.removeFirst(); //dequeue tile list
				BFSlist.add(cur);

				for (Tile neighbor : cur.neighbors) {
					if (!neighbor.isStart && neighbor.isWalkable()) {
						neighbor.isStart = true;
						templist.addLast(neighbor); //enqueue tile list
					}
				}
			}

			return BFSlist;
		}

		return null;
	}



	//TODO level 1: implement DFS traversal starting from s
	public static ArrayList<Tile> DFS(Tile s) {
		ArrayList<Tile> DFSlist = new ArrayList<Tile>();

		if (s != null) { //ensures it is a valid tile
			s.isStart = true;
			DFSlist.add(s);

			//Traversing the graph
			for (Tile neighbor : s.neighbors) {
				if (!neighbor.isStart && neighbor.isWalkable()) {
					DFSlist.addAll(DFS(neighbor));
				}
			}

			return DFSlist;
		}

		return null;
	}

}